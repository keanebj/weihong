(function() {
	var shouji = localStorage.getItem('phone');
	var sessionid = localStorage.getItem('sessionid');
	var uL = localStorage.getItem('strUrl');//生产
	var urlStr = uL + 'ybb/post?url=';
	$('#subQuestion').on('click', function() {
		var msg = $('.txarea1').val();
		console.log(msg);
		var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '","msg":"' + msg + '"}';
		console.log(paramStr);
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		console.log(data);
		$.ajax({
			type: "post",
			url: urlStr + "feedBackQuestionQuestionAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data);
				if(data.result == 'ok') {
					alert('问题提交成功!感谢您的支持')
				}
				$('.txarea1').val('');
				location.href = 'set.html'
			}
		})
	})
})();