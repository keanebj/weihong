$(function() {
//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl');//生产
	var url = window.location.href;
	if(url.indexOf('?') > 0) {
		var url = url.split("?")[1];
		
		var ids = url.split("&")[0];
		var coordinatexs = url.split("&")[1];
		var coordinateys = url.split("&")[2];
		var stationtypes = url.split("&")[3];
		
		var id = ids.split("=")[1];
		var coordinatex = coordinatexs.split("=")[1];
		var coordinatey = coordinateys.split("=")[1];
		var stationtype = stationtypes.split("=")[1];
		var jsname
//		console.log(stationtype)
		
		var param = '{"id":' + id + ',"coordinatex":' + coordinatex + ',"coordinatey":' + coordinatey + '}';
		param = getAES(param);
		var data = {
			'param': param,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			url: strUrl + "ybb/post?url=getDetailStationStationAction",
			contentType: "application/json",
			data: data,
			async: true,
			success: function(data) {
				data = getDAes(data);
				var jsonData = JSON.parse(data);
				var html = "";
//				console.log(jsonData.stationinfo)
				sessionStorage.setItem('mbData',JSON.stringify(jsonData.stationinfo))
				
				if(jsonData.stationinfo.stationtype == 1) {
					$("#imgC").attr("src", 'img/zsy.png')
				} else if(jsonData.stationinfo.stationtype == 2) {
					$("#imgC").attr("src", 'img/zsh.png')
				} else {
					$("#imgC").attr("src", 'img/yz.png')
				}
				
				$(".title").text(jsonData.stationinfo.name);
				var length = $(".title").text();
				if(length.length > 7) {
					var text = length.substr(0, 7);
					$(".title").text(text)
				}
				jsname = jsonData.stationinfo.name
				$("#name").text(jsname);
				$(".gas_addr").text(jsonData.stationinfo.address);
				$(".time").text(jsonData.stationinfo.opentime);
				var pricelist = jsonData.stationinfo.pricelist;
				var renderservices = jsonData.stationinfo.renderservices;
				var html = "";
				var text = "";
				for(var i = 0; i < pricelist.length; i += 1) {
					html += '<div class="col-33">';
					html += '<dl class="dl0">';
					html += '<dt>' + pricelist[i].gasno + '</dt>';
					html += '<dd>';
					html += '<span class="coorange_2">￥' + pricelist[i].price + '</span>';
					if(pricelist[i].cheap > 0) {
						html += '<span class="ico_gas_low">降</span>'
					} else {
						html += '<span></span>'
					}
					html += '</dd>';
					html += '</dl>';
					html += '</div>'
				}
				$(".row.gasList").html(html);
				for(var i = 0; i < renderservices.length; i += 1) {
					text += '<span>' + renderservices[i].servicename + '</span>'
				}
				$(".bgfff .services").html(text)
			}
		})
	}
	$(".button-fill").on("click", function(e, id, page) {
		var mbdata = JSON.parse(sessionStorage.getItem('mbData'))
		
//		console.log(mbdata)
		var gas_addr = $(".gas_addr").text();
                var city = remote_ip_info['city']+'市';
                var lngs = sessionStorage.getItem('bdx')
                var lata = sessionStorage.getItem('bdy')
                var street = ''
            var f  = 'http://api.map.baidu.com/direction?origin=latlng:' + lata + ',' + lngs + '|name:' + street + '&destination=latlng:' + mbdata.coordinatey + ',' + mbdata.coordinatex + '|name:' + gas_addr+" "+ jsname + '&mode=driving&region=' + city + '&output=html&src=ybb';
                console.log(f)
//   location.href = 'http://api.map.baidu.com/direction?origin=latlng:' + lata + ',' + lngs + '|name:' + street + '&destination=latlng:' + mbdata.coordinatey + ',' + mbdata.coordinatex + '|name:' + gas_addr+" "+ jsname + '&mode=driving&region=' + city + '&output=html&src=ybb';
	})
});
//var adr = 'http://api.map.baidu.com/direction?origin=latlng:39.970406980999,116.329090874|name:&destination=latlng:39.751616,116.574449|name:北京市通州区漷马路马驹镇西店村南马驹桥加油站 马驹桥加油站&mode=driving&region=北京市&output=html&src=ybb'
//var dse = 'URL: //uri.amap.com/navigation?from=116.317295,39.964286,startpoint&to=116.328979,39.964161,endpoint=海淀区中关村南大街5号北京理工大学北门东侧 北理工加油站&mode=car&policy=1&src=mypage&coordinate=gaode&callnative=0'
// 116.317295  39.964286
//http://api.map.baidu.com/direction?origin=latlng:39.970405167986,116.32908487458|name:&destination=latlng:39.964161,116.328979|name:海淀区中关村南大街5号北京理工大学北门东侧 北理工加油站&mode=driving&region=北京市&output=html&src=ybb