function scanM(argument) {
	cordova.plugins.barcodeScanner.scan(
		function(result) {
			result = JSON.stringify(result)
			sessionStorage.setItem('yhmoney', 0)
			sessionStorage.setItem('yhid', 0)
			sessionStorage.setItem('SSresult', result)
			var url = ''
			var rs = JSON.parse(result)
			if(rs.text) {
				url = "cashier.html"
			} else {
				url = "gasSiteList.html"
			}
			window.location.href = url
		},
		function(error) {
			                    alert("Scanning failed: " + error);
		}, {
			resultDisplayDuration: 0 //去掉扫描结果提示
		}
	);
}
