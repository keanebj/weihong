$(function() {
	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
//	var strUrl = "http://123.56.233.125:8000/agency2/";//生产
	localStorage.setItem('strUrl',strUrl)
	localStorage.setItem('lqyh',0)
	
	$("#regist").on("click", function() {
		window.location.href = "regist.html"
	});
	$("#logins").on("click", function() {
		var phone = $("#phone").val();
		var pw = $("#pw").val();
		if(pw == "") {
			alert("密码输入错误!");
			$("#pw").val("");
			return
		} else if($("#phone").val() == "" || $("#phone").val().length != 11) {
			alert("手机号输入错误！");
			return
		}
		$.get(strUrl + 'ca/get?url=auth/super/key/generate', function(data) {
//			console.log(data);
			var jsonData = JSON.parse(data);
			var result = jsonData.result;
			var data = jsonData.data;
			var modulus = data.modulus;
			var exponent = data.exponent;
			
			if(result == "0") {
				var passWord = RSAUtils.encryptedString(RSAUtils.getKeyPair(exponent, "", modulus), encodeURIComponent(pw));
				
				data = {
					"username": phone,
					"password": passWord,
					"modulus": modulus
				}
				
				data = JSON.stringify(data);
//				console.log(data)
				$.ajax({
					type: "post",
					url: strUrl + "ca/post?url=user/super/login",
					contentType: "application/json",
					data: data,
					async: true,
					success: function(data) {
//						console.log(data);
						data = JSON.parse(data)
						var results = data.result;
						if(results == '0') {
						localStorage.setItem("token", data.data.token);
						localStorage.setItem('username',phone)
						localStorage.setItem('phone',phone)
						localStorage.setItem('password',pw)
						lv(phone, pw)
						} else if(results == '903') {
							alert("图片验证码有误");
							return
						} else if(results == '102') {
							alert("用户密码不匹配错误");
							return
						} else if(results == '904') {
							alert("图片验证码错误数已达上限");
							return
						} else if(results == '905') {
							alert("图片验证码已过期");
							return
						} else if(results == '107') {
							alert("登录次数过多（需图片验证码步骤）");
							return
						} else if(results == '106') {
							alert("（登录成功）未绑定手机号，");
							return
						} else if(results == '999') {
							alert("系统错误");
							return
						} else if(results == '120') {
							alert("密码格式错误");
							return
						} else if(results == '121') {
							alert("此账号已被锁定");
							return
						} else if(results == '122') {
							alert("需重置密码才能登录");
							return
						}
						
					},
					error: function(m) {
//						console.log(m)
					}
				})

				//油帮帮免密登陆
				function lv(phone, pw) {
					var paramStr = '{"username":' + phone + ',"verification":"A512A50CD0DF6735","gasno":"93","cooperateName":"changan","loginpassword":"' + pw + '","commitpassword":"' + pw + '","inputflag": 0}';
//					console.log(paramStr);
					paramStr = getAES(paramStr);
					var data = {
						'param': paramStr,
						'version': "2.0.5"
					};
					data = JSON.stringify(data),
						$.ajax({
							type: "post",
							url: strUrl + "ybb/post?url=cooperateLoginResultLoginAction",
							contentType: "application/json",
							data: data,
							async: true,
							success: function(data, dd) {
								data = getDAes(data);
								data = JSON.parse(data);
//								console.log(data);
								if(data.result = "ok") {
									var sessionid = data.sessionid;
									localStorage.setItem("sessionid", sessionid);
//									localStorage.setItem("phone", phone);
									window.location.href = 'gasSiteList.html'
								}
							},
							error: function(a, b) {}
						})
				}
			} else {}
		});

	})
	$.get(strUrl + 'ca/get?url=auth/super/key/generate', function(data) {
			var jsonData = JSON.parse(data);
			var result = jsonData.result;
			var data = jsonData.data;
			var modulus = data.modulus;
			var exponent = data.exponent;
			if(result == "0") {
			
				var username = localStorage.getItem('username')
				var pw = localStorage.getItem('password')
//				console.log(username)
//				console.log(pw)
			
				var passWord = RSAUtils.encryptedString(RSAUtils.getKeyPair(exponent, "", modulus), encodeURIComponent(pw));
				data = {
					"username": username,
					"password": passWord,
					"modulus": modulus
				}
				data = JSON.stringify(data);
				$.ajax({
					type: "post",
					url: strUrl + "ca/post?url=user/super/login",
					contentType: "application/json",
					data: data,
					async: true,
					success: function(data) {
//						console.log(data);
						data = JSON.parse(data)
						var results = data.result;

						if(results == '0') {
						localStorage.setItem("token", data.data.token);
						localStorage.setItem('username',phone)
						localStorage.setItem('phone',phone)
							lv(username, pw)
						} else {
							$("#phone").val('');
							$("#pw").val('');
							localStorage.removeItem('phone')
							localStorage.removeItem('password')
							localStorage.removeItem('sessionid')
//							alert('帐号已过期请重新登陆')
							
						}
					},
					error: function(m) {
//						console.log(m)
					}
				})

				//油帮帮免密登陆
				function lv(phone, pw) {
					var paramStr = '{"username":' + phone + ',"verification":"A512A50CD0DF6735","gasno":"93","cooperateName":"changan","loginpassword":"' + pw + '","commitpassword":"' + pw + '","inputflag": 0}';
//					console.log(paramStr);
					paramStr = getAES(paramStr);
					var data = {
						'param': paramStr,
						'version': "2.0.5"
					};
					data = JSON.stringify(data),
						$.ajax({
							type: "post",
							url: strUrl + "ybb/post?url=cooperateLoginResultLoginAction",
							contentType: "application/json",
							data: data,
							async: true,
							success: function(data, dd) {
								data = getDAes(data);
								data = JSON.parse(data);
//								console.log(data);
								if(data.result = "ok") {
									var sessionid = data.sessionid;
									localStorage.setItem("sessionid", sessionid);
									localStorage.setItem("phone", phone);
									window.location.href = 'gasSiteList.html'
								}
							},
							error: function(a, b) {}
						})
				}
          
          
			} else {}
		});
});
