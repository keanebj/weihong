$(function() {
//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl');//生产
	var name = localStorage.getItem("phone");
	var stationno = "0GJ";
	var sessionid = localStorage.getItem("sessionid");
	var param = '{"username":"' + name + '","stationno":"' + stationno + '","sessionid":"' + sessionid + '"}';
	console.log(param)
	param = getAES(param);
	var data = {
		'param': param,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		url: strUrl + "ybb/post?url=getPayTypePaymentPageAction",
		contentType: "application/json",
		data: data,
		async: true,
		contentType: "application/json",
		success: function(data) {
			data = getDAes(data);
			var jsonData = JSON.parse(data);
			console.log(jsonData);
			if(jsonData.errorcode == "886") {
				alert("您的账号已过期，请重新登录!");
				window.location.href = "login.html"
			} else {
				var html = "";
				for(var i = 0; i < jsonData.paytypes.length; i += 1) {
					if(jsonData.paytypes[i].paytype == 4) {
						html += ''
					} else if(jsonData.paytypes[i].paytype == 7) {
						html += ''
					} else if(jsonData.paytypes[i].paytype == 3) {
						html += ''
					} else {
						html += '<li paytype="' + jsonData.paytypes[i].paytype + '"><img src ="' + jsonData.paytypes[i].logourl + '"><label>' + jsonData.paytypes[i].payname + '</label><span>' + jsonData.paytypes[i].desc + '</span></li>'
					}
				}
				$(".nomar .ol").html(html);
				var lis = $(".ol li");
				lis.on("click", function() {
					var _this = $(this).attr("paytype");
					var text = $(this).find('label').text();
					window.location.href = 'cashier.html?_this=' + _this + '&text=' + text
				})
			}
		}
	})
});