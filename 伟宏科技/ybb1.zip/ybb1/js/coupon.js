$(function() {
	var phone = localStorage.getItem('phone');
	var sessionid = localStorage.getItem('sessionid');
	var stationno = localStorage.getItem("gasno");
	//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl'); //生产
	var paramStr = '{"username":"' + phone + '","pageindex":"' + 0 + '","pagesize":"' + 30 + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: strUrl + "ybb/post?url=getAllowanceListActivityAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			console.log(data);
			//补贴不加载
			//			var str = template("btz", {
			//				'data': data.allwances
			//			});
			//			$(".btz").html(str)
		}
	});
	$("#yh").on("click", function() {
		var paramStr = '{"username":"' + phone + '","pageindex":"' + 0 + '","pagesize":"' + 30 + '","sessionid":"' + sessionid + '","stationno":"' + stationno + '","gasno":"' + 93 + '","productmoney":"' + 300 + '"}';
		console.log(paramStr);
		paramStr = getAES(paramStr);
		console.log(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=getCouponsListCouponsAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data)
				var n = sessionStorage.getItem('num')
				var str = template("yhj", {
					'data': data.coupons,
					'n': n
				});
				$(".yhj").html(str)
			}
		})
	});
	//	$(".youhuiq").on("click", function() {
	//		var money = $("#money").text();
	//		var _this = $(this);
	//		var id = _this.attr("id");
	//		console.log(id);
	//		if(money == "") {
	//			money = 0
	//		} else {
	//			money
	//		}
	//		sessionStorage.setItem("money", money);
	//		sessionStorage.setItem("id", id);
	//		window.location.href = 'cashier.html'
	//	});

	$(document).on('click', '.couBtn1', function() {
		$.prompt('请输入激活码', '激活码', function(value) {
			//			$.alert('Your name is "' + value + '". You clicked Ok button')
		}, function(value) {
			//			$.alert('Your name is "' + value + '". You clicked Cancel button')
		})
	})

	function YHn() {
		var paramStr = '{"username":"' + phone + '","sessionid":"' + sessionid + '"}';
		console.log(paramStr);
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=getDefaultPayTypePaymentPageAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data)
				if(data.defaultstatus == 1) {
					$.alert('您今天已经使用过优惠券')
					sessionStorage.setItem('defaultstatus', 1)
				} else {
					sessionStorage.setItem('defaultstatus', 0)
				}
			}
		})
	}
	YHn()
});

//账号：15677165242，密码：112899999say，支付了100，使用了8元优惠券

function ck(id, money) {
	var yesNo = sessionStorage.getItem('defaultstatus')
	if(yesNo == 0) {
		sessionStorage.setItem("yhmoney", money);
		sessionStorage.setItem("yhid", id);
	} else {
		sessionStorage.removeItem('yhmoney')
		sessionStorage.removeItem('yhid')
	}
	window.location.href = 'cashier.html'
}