var lqyh = localStorage.getItem('lqyh')
//console.log(lqyh)
if(lqyh == null || lqyh == 0) {
//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl');//生产
	var token = localStorage.getItem('token')
	$.get(strUrl + 'ca/get?url=user/info&token=' + token, function(data) {
		var jsonData = JSON.parse(data);
//		console.log(data)
		var result = jsonData.result;
		var data = jsonData.data;
		if(result == '0') {
			yhj(jsonData.data)
			var tel = data.tel;
			var Userinfo = JSON.stringify(data)
			sessionStorage.setItem('Userinfo', Userinfo)
			localStorage.setItem("phone", tel)

		} else {

		}
	})
}

function yhj(u) {
//	console.log(u)
	//	u = JSON.parse(u)
	var sessionid = localStorage.getItem('sessionid')
	var userCardLevel
	//正式的数据为0 测试的数据为1
	var ceshi = 1 ,cs 
	var yhArr = [[['changan10004', 'changan20008', 'changan30012', 'changan40016'],
					['changangold10008', 'changangold20016', 'changangold30024', 'changangold40032'],
					['changandia10010', 'changandia20020', 'changandia30030', 'changandia40040']
					],[['changanceshi100', 'changanceshi200', 'changanceshi300', 'changanceshi400'],
					['changanjinka100', 'changanjinka200', 'changanjinka300', 'changanjinka400'],
					['changanzuanshi100', 'changanzuanshi200', 'changanzuanshi300', 'changanzuanshi400']
					]]
	
	if(ceshi == 0){
		cs = 0  //正式数据
	}else{
		cs = 1  //测试数据
	}
	var zhengs = {
		"GeneralCard": {//普通
			"n": "1",
			"a": "GeneralCard",
			"m": yhArr[cs][0]
		},
		"SilverCard": {//银
			"n": "1",
			"a": "SilverCard",
			"m": yhArr[cs][0]
		},
		"GoldCard": {//金卡
			"n": "2",
			"a": "GoldCard",
			"m": yhArr[cs][1]
		},
		"DiamondCard": {  //钻石卡
			"n": "3",
			"a": "DiamondCard",
			"m": yhArr[cs][2]
		}
	}

	if(!(u.pInfo.cardLevel == undefined && u.cInfo.cardLevel == undefined)) {
		if(u.pInfo.cardLevel != undefined && u.cInfo.cardLevel != undefined) {
			//alert('全参')
			u = {
				'pInfo': u.pInfo.cardLevel,
				'cInfo': u.cInfo.cardLevel
			}
			if(u.pInfo.cardLevel == u.cInfo.cardLevel){
				userCardLevel = zhengs[u.pInfo].a
			}else if(zhengs[u.pInfo.cardLevel].n > zhengs[u.cInfo.cardLevel].n) {
				userCardLevel = zhengs[u.pInfo].a
			} else {
				userCardLevel = zhengs[u.cInfo].a
			}
		} else if(u.cInfo.cardLevel != undefined) {
//			alert('单参cInfo')
			userCardLevel = u.cInfo.cardLevel
		} else if(u.pInfo.cardLevel != undefined) {
//			alert('单参pInfo')
			userCardLevel = u.pInfo.cardLevel
		}
//		console.log()
		sessionStorage.setItem('level',zhengs[userCardLevel].n)
//		$.each(zhengs[userCardLevel].m, function(i, v) {
//			yhjlq(v, u.tel)
//		})
	} else {
		sessionStorage.setItem('level',1)
//		$.each(zhengs['GeneralCard'].m, function(i, v) {
//			yhjlq(v, u.tel)
//		})
	}
	localStorage.setItem('lqyh', 1)
	
	yhjInit()
}

function yhjInit(){
	var username = localStorage.getItem('phone')
	var level = sessionStorage.getItem('level')
	level = JSON.stringify(level)
	var sessionid = localStorage.getItem('sessionid')
	var paramStr = '{"cooperatename":"changan","password":"A512A50CD0DF6735","username":"' + username + '","level":' + level+ ',"sessionid":"' + sessionid+ '"}';
//	console.log(paramStr)
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: strUrl + "ybb/post?url=getCouponsCooperateAction",
		contentType: "application/json",
		data: dataStr,
		async: false,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
//			console.log(data)
		}
	})
}

function yhjlq(v, tel) {
	//console.log('开始领取')
	var sessionid = localStorage.getItem('sessionid')
	var paramStr = '{"username":"' + tel + '","activecode":"' + v + '","sessionid":"' + sessionid + '"}';
//	console.log(paramStr)
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: strUrl + "ybb/post?url=getActivityCodeActivityAction",
		contentType: "application/json",
		data: dataStr,
		async: false,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
//			console.log(data)
		}
	})
	console.log('结束领取')
}