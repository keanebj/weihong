document.write("<script language=javascript src='./js/ciphertext.js'></script>");
var myChandata;
var shouji = localStorage.getItem('phone');
var sessionid = localStorage.getItem('sessionid');
var sL = localStorage.getItem('strUrl');
var urlStr = sL + 'ybb/post?url=';
$(function() {
	$(document).on('click', '.NoBtn', function(e) {
		if(confirm('确认取消订单?')) {
			var did = $(e.target).parent().parent().attr('Did');
			var paramStr = '{"id":"' + did + '","sessionid":"' + sessionid + '"}';
			YesOrNoPayment(paramStr, 'cancleDetailOrderAction')
		}
	});
	$(document).on('click', '.YesBtn', function(e) {
		var did = $(e.target).parent().parent().attr('Did');
		var dt = $(e.target).parent().parent().attr('Dtype');
		var paramStr = '{"id":"' + did + '","sessionid":"' + sessionid + '"}';
		console.log(dt);
		console.log(dt);
		if(dt == 0) {
			console.log(0)
		} else if(dt == 1) {
			aliPaySubmitH5PayServerAction(xqList,shouji,sessionid)
		} else if(dt == 2) {
			weChatSignH5PayServerAction(xqList)
		} else if(dt == 3) {
			bindBankCardBankCardAction(xqList)
		}
	})
});
getPersonalCenter();

function getPersonalCenter() {
	var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getPersonalCenterPersonalCenterAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			data.phone = shouji;
			var str = template("Yme", {
				data: data
			});
			$(".Y_me").html(str)
		}
	})
}

function getMesList() {
	getMsgMessageAction(0)
}

function getMesListDel() {
	getMsgMessageAction(1)
}

function getMsgMessageAction(i) {
	var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '","clearflag":' + i + '}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getMsgMessageAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			data.phone = shouji;
			var str = template("MesList", {
				data: data.messages
			});
			$(".MesList").html(str)
		}
	})
}

function YesOrNoPayment(paramStr, dz) {
	var paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "" + dz,
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data)
		}
	})
}


var myZt = 1;
if(myZt == 1) {
	myChan()
} else if(myZt == 2) {
	Y_me_jiayouLog_xq(null);
}

function myChan() {
	myZt = 1;
	var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '"}';
	console.log(paramStr)
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getOrderRecordOrderAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			sessionStorage.setItem('data_order', data.order);
			var arr = [];
			console.log(data.order)
			$.each(data.order, function(i, v) {
				arr.push(v);
				if(i + 1 == 10) {
					return false
				}
			});
			var str = template("one", {
				data: arr
			});
			$("#clists").html(str)
		}
	});
}
var xqList = '';

function Y_me_jiayouLog_xq(id) {
	myZt = 2;
	if(id == null) {
		id = localStorage.getItem('payId')
	}
	var paramStr = '{"id":"' + id + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getDetailOrderOrderAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			xqList = data.orderinfo;
			console.log(data);
			localStorage.setItem('payNum', data.orderinfo.num);
			localStorage.setItem('payId', data.orderinfo.id);
			listData(data.orderinfo);
			console.log(data)
		}
	})
}

function aliPaySubmitH5PayServerAction(data,shouji,sessionid) {
    
			data = JSON.stringify(data)
//			var openUrlStr = 'https://test201503.yobangbang.com/ybbWebServerPay/index.html?data='+data+'&shouji='+shouji+'&sessionid='+sessionid+'&payType=alipay'
			var openUrlStr = 'https://test201503.yobangbang.com/ybbh5/index.html?data='+data+'&shouji='+shouji+'&sessionid='+sessionid+'&payType=alipay'
			openUrlStr = encodeURI(openUrlStr)
			window.open(openUrlStr,'_system','location=0')
}

function weChatSignH5PayServerAction(data) {
	var _data = data;
	console.log(returnCitySN.cip);
	var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '","body":"油帮帮加油支付","device_info":"WEB","out_trade_no":"' + data.num + '","total_fee":"' + data.factmoney*100 + '","spbill_create_ip":"' + returnCitySN.cip + '","scene_info":{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}}'
	paramStr1 = paramStr;
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	var responseText;
	$.ajax({
		type: "post",
		url: urlStr + "weChatSignH5PayServerAction",
		contentType: "application/json",
		data: dataStr,
		dataType: "json",
		async: false,
		success: function(data) {
			console.log(data)
		},
		error: function(data) {
			responseText = data.responseText;
			responseText = responseText.replace(/↵/g, "");
			responseText = responseText.replace(/\s/g, "");
			responseText = getDAes(responseText);
			responseText = JSON.parse(responseText);
			console.log(responseText)
		}
	});
	var xmlStr = '<xml><appid>' + responseText.appid + '</appid><body>油帮帮加油支付</body><mch_id>' + responseText.mch_id + '</mch_id><nonce_str>' + responseText.nonce_str + '</nonce_str><device_info>WEB</device_info><notify_url>' + responseText.notify_url + '</notify_url><out_trade_no>' + _data.num + '</out_trade_no>' + '<scene_info>{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}</scene_info><spbill_create_ip>' + returnCitySN.cip + '</spbill_create_ip>' + '<total_fee>' + _data.factmoney*100 + '</total_fee><trade_type>MWEB</trade_type><sign>' + responseText.sign + '</sign></xml>';
//	var openUrlStr = 'https://test201503.yobangbang.com/ybbWebServerPay/index.html?data='+xmlStr+'&payType=weixin';
	var openUrlStr = 'https://test201503.yobangbang.com/ybbh5/index.html?data='+xmlStr+'&payType=weixin';
	openUrlStr = encodeURI(openUrlStr)
	window.open(openUrlStr,'_system','location=0')
//	console.log(xmlStr);
//	$.ajax({
//		type: "post",
//		url: 'http://123.56.233.125:8090/agency2/wx/postjson?url=unifiedorder',
//		contentType: "application/xml",
//		data: xmlStr,
//		dataType: "xml",
//		async: true,
//		success: function(data) {
//			console.log(data);
//				var xmlUrl = $(data).find('mweb_url').text();
//				console.log(xmlUrl);
//				var url = 'www.yobangbang.com';
//				if(/MSIE (\d+\.\d+);/.test(navigator.userAgent) || /MSIE(\d+\.\d+);/.test(navigator.userAgent)) {
//					var referLink = document.createElement('a');
//					referLink.href = url;
//					document.body.appendChild(referLink);
//					referLink.click()
//				} else {
//					location.href = url
//				}
//		},
//		error: function(e) {
//			console.log(e)
//		}
//	})
}

function bindBankCardBankCardAction(data) {
	var paramStr = '{"username":"' + shouji + '","sessionid":"' + sessionid + '","body":"油帮帮加油支付","out_trade_no":"' + data.num + '","total_fee":"' + data.factmoney + '","spbill_create_ip":"' + returnCitySN.cip + '","scene_info":{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}}'
	paramStr1 = paramStr;
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	var responseText;
	$.ajax({
		type: "post",
		url: urlStr + "weChatSignH5PayServerAction",
		contentType: "application/json",
		data: dataStr,
		dataType: "json",
		async: false,
		success: function(data) {
			console.log(data)
		},
		error: function(data) {
			responseText = data.responseText;
			responseText = responseText.replace(/↵/g, "");
			responseText = responseText.replace(/\s/g, "");
			responseText = getDAes(responseText);
			responseText = JSON.parse(responseText);
			console.log(responseText)
		}
	});
	console.log(data);
}

function listData(data) {
	$("#xqlb").empty();
	console.log(data);
	var Dname = ['订单号', '订单状态', '加油金额', '优惠', '支付金额', '支付方式', '获得米油', '下单时间', '加油站', '油号'];
	var arr = [data.num, data.status, data.productmoney, data.discount, data.factmoney, data.paytype, data.score, data.time, data.name, data.gasno];
	var arrClass = ['abc', 'rightFont', 'moneyColor'];
	var c = '';
	var dStr = '';
	if(data.status == '0') {
		dStr += '<ul class="c">';
		arr[1] = '未支付'
	} else if(data.status == '1') {
		dStr += '<ul class="a">';
		arr[1] = '已完成'
	} else if(data.status == '-1') {
		dStr += '<ul class="b">';
		arr[1] = '已取消'
	}
	if(data.paytype == 1) {
		arr[5] = '支付宝'
	} else if(data.paytype == 2) {
		arr[5] = '微信'
	} else if(data.paytype == 3) {
		arr[5] = '银行卡'
	}
	$.each(arr, function(i, v) {
		if(i == 1) {
			c = arrClass[1]
		} else if(i == 4) {
			c = arrClass[2]
		} else {
			c = arrClass[0]
		}
		dStr += '<li class="item-content"><div class="item-media"><i class="icon icon-f7"></i></div><div class="item-inner"><div class="item-title">' + Dname[i] + '</div><div class="item-after ' + c + '">' + arr[i] + '</div></div></li>'
	});
	if(data.status == '0') {
		dStr += '<div class="content-block"><div class="row" Dtype=' + data.paytype + ' Did=' + data.id + '><div class="col-50"><a href="#" class="button  button-big  button-fill button-light NoBtn">取消订单</a></div><div class="col-50"><a href="#" class="button  button-big  button-fill button-blue YesBtn">立即支付</a></div></div></div>'
	}
	dStr += '</ul>';
	$('#xqlb').append(dStr);
}

function orderPaymentOrderAction(id) {
	var paramStr = '{"id":"' + id + '","username":"' + shouji + '","sessionid":"' + sessionid + '","WIDout_trade_no":"' + sessionid + '","WIDsubject":"' + sessionid + '","WIDtotal_amount":"' + sessionid + '","body":"' + sessionid + '","payUse":"' + sessionid + '","return_url":"' + sessionid + '"}';
	console.log(xqList);
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "aliPaySubmitH5PayServerAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			sessionStorage.setItem('oo', data);
			console.log(data);
//			$('#xqlb').append(data.form);
			
		}
	})
}
var pays = {};

function getCouponsList() {
	var paramStr = '{"username":"' + shouji + '","pageindex":"' + 0 + '","pagesize":"' + 30 + '","inputflag":"' + 0 + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getCouponsListCouponsAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			console.log(data)
			var str = template("yhj", {
				'data': data.coupons
			});
			$(".yhj").html(str);
		}
	})
}

function getAllowanceList() {
	var paramStr = '{"username":"' + shouji + '","pageindex":"' + 0 + '","pagesize":"' + 30 + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getAllowanceListActivityAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data);
			var str = template("btz", {
				'data': data.allwances
			});
			$(".btz").html(str)
		}
	})
}
$(document).on('click', '.prompt-title-ok-cancel', function() {
	$.prompt('请输入激活码', '激活码', function(value) {
		var paramStr = '{"username":"' + shouji + '","activecode":"' + value + '","sessionid":"' + sessionid + '"}';
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: urlStr + "getActivityCodeActivityAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				$.alert(data.message);
				getCouponsList()
			}
		})
	}, function(value) {})
});

function aa(a) {
	return a
}

function getActivityCode(value) {
	var paramStr = '{"username":"' + shouji + '","activecode":"' + value + '","sessionid":"' + sessionid + '"}';
	paramStr = getAES(paramStr);
	var data = {
		'param': paramStr,
		'version': "2.0.5"
	};
	var dataStr = JSON.stringify(data);
	$.ajax({
		type: "post",
		url: urlStr + "getActivityCodeActivityAction",
		contentType: "application/json",
		data: dataStr,
		async: true,
		success: function(data) {
			data = getDAes(data);
			data = JSON.parse(data)
		}
	})
}

function ckYN() {
	var fl = $("input").is(':checked');
	modifySafePassword();
	if(tf) {
		if(fl == true) {
			var paramStr = '{"username":"' + shouji + '","openflag":"' + 1 + '","safepassword":"' + $('#safepassword').val() + '","sessionid":"' + sessionid + '"}'
		} else {
			var paramStr = '{"username":"' + shouji + '","openflag":"' + 0 + '","safepassword":"' + $('#safepassword').val() + '","sessionid":"' + sessionid + '"}'
		}
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
	}
}

function sz() {
	window.location.href = 'set.html'
}
document.addEventListener("resume", onResume, false);

function onResume() {
	var hash=window.location.hash;
	if(hash=='#Y_me_jiayouLog_xq'){
		Y_me_jiayouLog_xq()
	}
}
