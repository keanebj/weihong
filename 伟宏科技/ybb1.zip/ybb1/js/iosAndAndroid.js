sessionStorage.setItem('a', 0)
var iDevices = [
	'iPad Simulator',
	'iPhone Simulator',
	'iPod Simulator',
	'iPad',
	'iPhone',
	'iPod'
];

if(!!navigator.platform) {
	while(iDevices.length) {
		if(navigator.platform === iDevices.pop()) {
			$('head').append('<style type="text/css"> .headerIos{ padding-top:20px;height:66px;}  .content {border-top:22px solid transparent}</style>')
			$('header').addClass('headerIos')
		}
	}
}
