(function() {
//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl');//生产
	$("#yzm").attr("disabled", true).css("background", "#ccc");
	$("#xyb").attr("disabled", true).css("background", "#ccc");
	
	$("#phone").on('input', function() {
		if($(this).val().length == 11) {
			qClick()
		}
	});
	$("#yamid").on('input', function() {
		if($(this).val().length >= 3) {
			$('#xyb').removeAttr('disabled').css("background", "#0894ec").attr('href','#Y_me_xiayibu')
		}
	});
	$("#yzid").on('input', function() {
		if($(this).val().length == 4) {
			$("#yzm").removeAttr("disabled");
			$("#yzm").css("background", "#0894ec")
//			#Y_me_xiayibu
		}
	});
	$('#yzm').bind('click', function() {
		if(!checkMobile($('input[type="tel"]').val())) {
			$.alert('手机号码不正确！')
		} else {
			
			var data = {
				"tel": $('#phone').val(),
				"picCode": $('#yzid').val(),
				"biz": '1'
			};
			data = JSON.stringify(data)
			$.ajax({
				type: "post",
				url: strUrl + "ca/post?url=auth/sms/send",
				contentType: "application/json",
				data: data,
				async: true,
				success: function(data) {
					var jsonData = JSON.parse(data);
					data = jsonData.result;
					if(data == "901") {
						$.alert("手机号格式有误!");
						return
					} else if(data == "903") {
						$.alert("图片验证码有误!");
						return
					} else if(data == "905") {
						$.alert("图片验证码已过期!");
						return
					} else if(data == "906") {
						$.alert("短信验证码有误!");
						return
					} else if(data == "907") {
						$.alert("短信验证码已过期");
						return
					} else if(data == "401") {
						$.alert("参数错误!");
						return
					} else if(data == "910") {
						$.alert("手机号已注册！");
						return
					}
					var count = 59;
					var countdown = setInterval(CountDown, 1000);
					$.alert('验证码已经发出！');
					function CountDown() {
						$("#yzm").attr("disabled", true);
						$("#yzm").text("请在" + count + "秒重试");
						if(count == 0) {
							$("#yzm").text("获取验证码").removeAttr("disabled");
							clearInterval(countdown)
						}
						count -= 1
					}
				}
			})
		}
	});
	var modulus;
	var exponent;
	$("#xyb").on("click", function() {
		$.get(strUrl + 'ca/get?url=auth/super/key/generate', function(data) {
			var jsonData = JSON.parse(data);
			modulus = jsonData.data.modulus;
			exponent = jsonData.data.exponent;
			console.log(modulus)
		})
	});
	$("#regist").on("click", function() {
		var pw = $("#pw").val();
		var str = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{4,15}$/;
		if(!(str.test(pw)) || pw == "") {
			$.alert("密码不符合规则请重新输入！");
			$("#pw").val("");
			return
		} else if($("#yamid").val() == "") {
			$.alert("验证码不能为空！");
			return
		} else if($("#phone").val() == "") {
			$.alert("手机号不能为空！");
			return
		}
		var passWord = RSAUtils.encryptedString(RSAUtils.getKeyPair(exponent, "", modulus), encodeURIComponent(pw));
		data = {
			"tel": $("#phone").val(),
			"smsCode": $("#yamid").val(),
			"password": passWord,
			"modulus": modulus
		}, console.log(data);
		$.ajax({
			type: "post",
			url: strUrl + "ca/post?url=user/super/register",
			contentType: "application/json",
			data: JSON.stringify(data),
			dataType: "json",
			async: true,
			success: function(data) {
				console.log(data);
				var result = data.result;
				if(result == "910") {
					$.alert("手机号已注册！");
					return
				} else if(result == "903") {
					$.alert("图片验证码有误!");
					return
				} else if(result == "905") {
					$.alert("图片验证码已过期!");
					return
				} else if(result == "901") {
					$.alert("手机号格式有误!");
					return
				} else if(result == "906") {
					$.alert("短信验证码有误!");
					return
				} else if(result == "907") {
					$.alert("短信验证码已过期!");
					return
				} else if(result == "999") {
					$.alert("系统错误!");
					return
				} else if(result == "102") {
					$.alert("用户密码不匹配错误!");
					return
				} else if(result == "120") {
					$.alert("密码格式错误");
					return
				} else if(result == 0) {
					data = {
						"tel": $("#phone").val(),
						"password": passWord,
						"modulus": modulus
					}, $.ajax({
						type: "post",
						url: strUrl + "ca/post?url=user/login",
						contentType: "application/json",
						data: JSON.stringify(data),
						dataType: "json",
						async: true,
						success: function(data) {
							console.log(data);
							window.location.href = "gasSiteList.html"
						}
					});
					var val = $("#phone").val();
					var paramStr = '{"username":' + val + ',"verification":"A512A50CD0DF6735","gasno":"93","cooperateName":"changan"}';
					paramStr = getAES(paramStr);
					var data = {
						'param': paramStr,
						'version': "2.0.5"
					};
					data = JSON.stringify(data), $.ajax({
						type: "post",
						url: strUrl + "ybb/post?url=cooperateLoginResultLoginAction",
						contentType: "application/json",
						data: data,
						async: true,
						success: function(data, dd) {
							data = getDAes(data);
							data = JSON.parse(data);
							console.log(data);
							if(data.result = "ok") {
								var sessionid = data.sessionid;
								localStorage.setItem("sessionid", sessionid);
								localStorage.setItem("phone", val)
							}
						},
						error: function(a, b) {}
					})
				}
			}
		})
	})
})();

function qClick() {
	var aa = 'http://scrm.changan.com.cn/scrm-app-web/auth/pic/send?picKey=' + $('#phone').val(); //正式
//	var aa = 'http://scrmtext.changan.com.cn/scrm-app-web/auth/pic/send?picKey=' + $('#phone').val(); //测试
	$('#yzimg').attr('src', aa)
}

function checkMobile(text) {
	if(text !== '') {
		if(!(/^1[3|4|5|8][0-9]\d{4,8}$/.test(text))) {
			$('#phone').addClass('redTell');
			return false
		} else {
			$('#phone').removeClass('redTell');
			return true
		}
	}
}

function checkPass(text) {
	var pPattern = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,12}$/;
	if(text !== '') {
		if(!(pPattern.test(text))) {
			$('#pw').addClass('redTell')
		} else {
			$('#pw').removeClass('redTell')
		}
	}
}