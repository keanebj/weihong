$(function() {
//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
//	var strUrl = localStorage.getItem('strUrl');//生产
//	var aaa = sessionStorage.getItem('SSresult')
//	aaa = JSON.parse(aaa)
//	var aa = aaa.text
	  var aa = {"text":{"s":"0GJ","n":"油帮帮测试专用加油站","e":"1","g":"92","k":"c74e81f9e996eaeba4ecee34799e039a"}} //1
//	aa = JSON.parse(aa)
	  aa = aa.text//1
	var stationno = aa.s
	var name = aa.n
	var employeeno = aa.e
	var gasno = aa.g
	var phone = localStorage.getItem("phone");
	var sessionid = localStorage.getItem("sessionid");
	//	$.alert(stationno,name,employeeno,gasno)

	var yhMoney = sessionStorage.getItem('yhmoney')
	if(yhMoney == null) yhMoney = 0
	var yhid = sessionStorage.getItem('yhid')
	if(yhMoney != 0 && yhid != 0) {
		$('#youhui').val('优惠金额' + yhMoney + '元')
	}

	$("#gasno").text(gasno);
	$("#name").text(name);
	$("#employeeno").val(employeeno);

	if(sessionStorage.getItem == "") {
		$("#num").val()
	} else {
		var nums = sessionStorage.getItem("num");
		$("#num").val(nums)
	}
	$("#num").blur(function() {
		var num = $("#num").val();
		sessionStorage.setItem("num", num)
	});
	var url = window.location.href;
	if(url.indexOf('?') > 0) {
		var payname = '0';
		var paytype = '';
		var params = window.location.href.split("?")[1];
		var tmp = params.split("&");
		payname = decodeURI(tmp[1].split("=")[1]);
		paytype = tmp[0].split("=")[1];
		$("#mode").val(payname).attr('paytype', paytype)
	}

	$('.retu').on('click', function() {
		sessionStorage.setItem('yhid', 0)
		sessionStorage.setItem('yhmoney', 0)
		window.location.href = 'gasSiteList.html'
	})
	//提交支付 
	$(".btns").on("click", function() {
		var num = $("#num").val();
		var youhui = $("#youhui").val();
		var paytype = $("#mode").attr("paytype");
		var couponid = sessionStorage.getItem('yhid')
		if(couponid == "" || couponid == undefined) {
			if(paytype == 2)
				couponid = "-1"
			else
				couponid = "0"

		} else {
			couponid = couponid
		}
		var mode = $("#mode").val();
		if(num == "") {
			alert("请输入您的加油金额!");
			return
		} else if(mode == "") {
			alert("请选择您的支付方式!");
			return
		}
		$('.btns').attr('disabled',true).text('正在支付').css('background-color','#666')
		var paramStr = '{"username":"' + phone + '","stationno":"' + stationno + '","sessionid":"' + sessionid + '","gasno":"' +
			gasno + '","productmoney":"' + num + '","paytype":"' + paytype + '","couponid":"' + couponid + '"}';
		//		var paramStr = '{"username":"13269074211","stationno":"0GJ","sessionid":"'+sessionid+'","gasno":"93","productmoney":"1","paytype":"1","couponid":"-1"}'
		$('#ccc').html(paramStr)
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=factMoneyPaymentPageAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data)
				var factmoney = data.factmoney;
				$("#money").text(factmoney);
				shengc_dingdan(factmoney)
			}
		});

		function shengc_dingdan(factmoney) { //factmoney实际支付金额 需要计算
			var paramStr = '{"username":"' + phone + '","stationno":"' + stationno + '","employeeno":"' + employeeno + '","gasno":"' + gasno + '","couponid":"' +
				couponid + '","productmoney":"' + num + '","factmoney":"' + factmoney + '","paytype":"' + paytype + '","sessionid":"' + sessionid + '"}';
			$('#ddd').html(paramStr)

			paramStr = getAES(paramStr);
			var data = {
				'param': paramStr,
				'version': "2.0.5"
			};
			var dataStr = JSON.stringify(data);
			$.ajax({
				type: "post",
				url: strUrl + "ybb/post?url=submitPaymentH5PaymentPageAction",
				contentType: "application/json",
				data: dataStr,
				async: true,
				success: function(data) {
					data = getDAes(data);
					data = JSON.parse(data);
					console.log(data)
					dataXq(data.id)
				}
			})
		}
	});
	//获取详情
	function dataXq(id) {
		//	myZt = 2;
		//	if(id == null) {
		//		id = localStorage.getItem('payId')
		//	}
		var paramStr = '{"id":"' + id + '","sessionid":"' + sessionid + '"}';
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=getDetailOrderOrderAction",
			contentType: "application/json",
			data: dataStr,
			async: true,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data)
				if(paytype == '1') {
					aliPaySubmitH5PayServerAction(data.orderinfo, phone, sessionid)
				} else if(paytype == '2') {
					weChatSignH5PayServerAction(data.orderinfo, phone, sessionid)
				}
			}
		})
	}
	//支付宝H5支付方法 
	function aliPaySubmitH5PayServerAction(data, phone, sessionid) {
		data = JSON.stringify(data)
		var openUrlStr = 'https://test201503.yobangbang.com/ybbWebServerPay/index.html?data=' + data + '&shouji=' + phone + '&sessionid=' + sessionid + '&payType=alipay'
//		var openUrlStr = 'http://test201503.yobangbang.com/ybbh5/index.html?data=' + data + '&shouji=' + shouji+ '&sessionid=' + sessionid + '&payType=alipay'
		
		//   alert(openUrlStr)
		openUrlStr = encodeURI(openUrlStr)
		window.open(openUrlStr, '_system', 'location=0')
		//cordova.InAppBrowser.open(openUrlStr,'_system','location=0')
	}

	function weChatSignH5PayServerAction(data) {
		var _data = data;
		//		var paramStr = '{"username":"' + phone + '","sessionid":"' + sessionid + '","body":"油帮帮加油支付","out_trade_no":"' + data.num + '","total_fee":"' + data.factmoney*100 + '","spbill_create_ip":"' + returnCitySN.cip + '","scene_info":{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}}'
		var paramStr = '{"username":"' + phone + '","sessionid":"' + sessionid + '","body":"油帮帮加油支付","device_info":"WEB","out_trade_no":"' + data.num + '","total_fee":"' + data.factmoney * 100 + '","spbill_create_ip":"' + returnCitySN.cip + '","scene_info":{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}}'
		paramStr1 = paramStr;
		console.log(paramStr);
		console.log(strUrl + "weChatSignH5PayServerAction");
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		var responseText;
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=weChatSignH5PayServerAction",
			contentType: "application/json",
			data: dataStr,
			dataType: "json",
			async: false,
			success: function(data) {
				console.log(data)
			},
			error: function(data) {
				responseText = data.responseText;
				responseText = responseText.replace(/↵/g, "");
				responseText = responseText.replace(/\s/g, "");
				responseText = getDAes(responseText);
				responseText = JSON.parse(responseText);
				console.log(responseText)
			}
		});
		var xmlStr = '<xml><appid>' + responseText.appid + '</appid><body>油帮帮加油支付</body><mch_id>' + responseText.mch_id + '</mch_id><nonce_str>' + responseText.nonce_str + '</nonce_str><device_info>WEB</device_info><notify_url>' + responseText.notify_url + '</notify_url><out_trade_no>' + _data.num + '</out_trade_no>' + '<scene_info>{"h5_info":{"h5_info":{"type":"Wap","wap_url":"http://121.42.182.198:8011/Webybb/refuelingRecord.html","wap_name":"油帮帮"}}}</scene_info><spbill_create_ip>' + returnCitySN.cip + '</spbill_create_ip>' + '<total_fee>' + _data.factmoney * 100 + '</total_fee><trade_type>MWEB</trade_type><sign>' + responseText.sign + '</sign></xml>';
		var openUrlStr = 'https://test201503.yobangbang.com/ybbWebServerPay/index.html?data=' + xmlStr + '&payType=weixin&id=' + _data.id + '&num=' + _data.num + '&sessionid=' + sessionid;
		openUrlStr = encodeURI(openUrlStr);
		window.open(openUrlStr, '_system', 'location=0');
	}
	document.addEventListener("resume", onResume, false);

	function onResume() {
		var pathname = window.location.pathname;
		pathname = pathname.split("/");
		var pathname1 = ''
		for(var i = 0; i < pathname.length; i++) {
			if(i < pathname.length - 1 && pathname[i] != "") {
				pathname1 += '/' + pathname[i]
			}
		}
		var dizhi = pathname.pop();
		if(dizhi == 'cashier.html') {
			window.location.pathname = pathname1 + '/refuelingRecord.html'
		}
	}

	function yhjInit2() {
		var username = localStorage.getItem('phone')
		var level = sessionStorage.getItem('level')
		var sessionid = localStorage.getItem('sessionid')
		var paramStr = '{"cooperatename":"changan","password":"A512A50CD0DF6735","username":"' + username + '","level":"' + level + '","sessionid":"' + sessionid + '"}';
		console.log(paramStr)
		paramStr = getAES(paramStr);
		var data = {
			'param': paramStr,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			type: "post",
			url: strUrl + "ybb/post?url=getCouponsCooperateAction",
			contentType: "application/json",
			data: dataStr,
			async: false,
			success: function(data) {
				data = getDAes(data);
				data = JSON.parse(data);
				console.log(data)
			}
		})
	}
	yhjInit2()
});