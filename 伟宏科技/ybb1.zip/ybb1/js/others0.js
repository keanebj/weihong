/**
 * Created by Administrator on 17.6.12.
 */
//var strUrl = "https://test201503.yobangbang.com/agency/"

//	var strUrl = "http://123.56.233.125:8090/agency2/";//测试
	var strUrl = localStorage.getItem('strUrl');//生产
	
var reg_six = /^\d{6}$/;

function enable_pwd(obj) {
	var _thisCBox = $(obj).children('input'),
		toggle = _thisCBox.prop("checked");
	_thisCBox.prop("disabled", true);
	if(toggle) {
		_thisCBox.prop("checked", false)
	} else {
		_thisCBox.prop("checked", true);
		$.router.load("#Y_pwdset_enabled")
	}
};
$('.list-block.media-list ul').html(sessionStorage.getItem('text'));
$(function() {
	
	sessionStorage.setItem('yhid', '')
	sessionStorage.setItem('yhmoney', 0)
	var arr = [];
	//    var geolocation = new BMap.Geolocation();
	//    geolocation.getCurrentPosition(function(r) {
	//alert(r,3)
	getLocation()

	function getLocation() {
		if(navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(showPosition, showError);
		} else {
			x.innerHTML = "Geolocation is not supported by this browser.";
		}
	}
	function showError(error) {
		switch(error.code) {
			case error.PERMISSION_DENIED:
				alert("用户拒绝了地理定位的要求")
				break;
			case error.POSITION_UNAVAILABLE:
				alert("位置信息不可用")
				break;
			case error.TIMEOUT:
				alert("请求超时")
				break;
			case error.UNKNOWN_ERROR:
				alert("未知错误")
				break;
		}
	}
	showPosition()
	function showPosition(position) {
		//全局定位
//      var y = position.coords.latitude;
//      var x = position.coords.longitude;
		  //北京
          var y = 39.96331781398048
          var x = 116.3163908167551
          //南京
//        var y = 31.95431781398048
//        var x = 118.9093908167551
          sessionStorage.setItem('x', x)
          sessionStorage.setItem('y', y)

		sessionStorage.removeItem("yhmoney");
		sessionStorage.removeItem("yhid");
		var ggPoint = new BMap.Point(x, y);

		//坐标转换完之后的回调函数
		translateCallback = function(data) {
			if(data.status === 0) {
				sessionStorage.setItem('bdx', data.points[0].lng)
				sessionStorage.setItem('bdy', data.points[0].lat)
			}
		}
		//转换方法
		var convertor = new BMap.Convertor();
		var pointArr = [];
		pointArr.push(ggPoint);
		convertor.translate(pointArr, 1, 5, translateCallback)

		gasno(93);
		var val = localStorage.getItem("phone");
		var param = '{"username":' + val + ',"login":' + true + ',"gasno":93,"coordinatey":' + y + ',"coordinatex":' + x + ',"gasnoid":"1"}';
		//  alert("SSSSS" + param)
		param = getAES(param);
		var data = {
			'param': param,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			url: strUrl + "ybb/post?url=getStationMessageStationAction",
			contentType: "application/json",
			data: data,
			async: true,
			success: function(data) {
				data = getDAes(data);
				var jsonData = JSON.parse(data);
				var gasnolist = jsonData.gasnolist;
				var stations = jsonData.stations;
				var errorcode = jsonData.errorcode;
				var html = "";
				if(errorcode != "0") {
					alert("暂无推荐加油站");
					return
				} else {
					for(var i = 0; i < gasnolist.length; i++) {
						html += '<li id=' + gasnolist[i].gasnoid + '>' + gasnolist[i].gasno + '</li>'
					}
					$(".gasDrop ul").html(html); // 油号
					$(".gasDrop ul li").on("click", function() {
						event.stopPropagation();
						$(this).parent().addClass('hide')
						console.log($(this).parent().siblings('span'))

						$(this).parent().siblings('span').html($(this).html())

						$(this).parents('span').val($(this).html())
						var val = $(this).html();
						var gasnoid = $(this)[0].id
						if(val.length == 8) {
							str = val.substr(0, 2);
							gasno1(str, gasnoid)
						} else {
							str1 = val.substr(0, 1);
							gasno1(str1, gasnoid)
						}
					})

				}
			},
			error: function(e) {
//				alert(e)
			}

		})

	}

	

	var coordinatex = sessionStorage.getItem('x')
	var coordinatey = sessionStorage.getItem('y')


	function gasno(str) {
		var str = str;
		var coordinatex = sessionStorage.getItem('x')
		var coordinatey = sessionStorage.getItem('y')
		var val = localStorage.getItem("phone");
		var param = '{"username":' + val + ',"login":' + true + ',"gasno":' + str + ',"coordinatey":' + coordinatey + ',"coordinatex":' + coordinatex + ',"gasnoid":"2"}';
		param = getAES(param);
		var data = {
			'param': param,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			url: strUrl + "ybb/post?url=getStationMessageStationAction",
			contentType: "application/json",
			data: data,
			async: true,
			success: function(data) {
				data = getDAes(data);
				console.log(data)
				var jsonData = JSON.parse(data);
				var gasnolist = jsonData.gasnolist;
				var stations = jsonData.stations;
				var html = "";
				var text = "";
				if(stations != undefined) {
					for(var s = 0; s < stations.length; s++) {
						var obj = {};
						obj['coordinatex'] = stations[s].coordinatex;
						obj['coordinatey'] = stations[s].coordinatey;
						obj['id'] = stations[s].id;
						arr[s] = obj
					}
					sessionStorage.setItem('listArr',JSON.stringify(arr))
					for(var i = 0; i < stations.length; i += 1) {
						text += '<li  id = ' + stations[i].stationid + ' coordinatex = ' + stations[i].coordinatex + ' coordinatey = ' + stations[i].coordinatey +' stationtype = ' + stations[i].stationtype + '>';
						text += '<a href="#"  class=""external">';
						text += '<div class="item-content">';
						if(stations[i].stationtype == 1) {
							text += '<div class="item-media"><img src="img/zsy.png"></div>'
						} else if(stations[i].stationtype == 2) {
							text += '<div class="item-media"><img src="img/zsh.png"></div>'
						} else {
							text += '<div class="item-media"><img src="img/yz.png"></div>'
						}
						text += '<div class="item-inner">';
						text += '<div class="item-title-row">';
						text += '<div class="item-title">' + stations[i].name + '</div>';
						text += '<div class="item-after price">';
						text += '<div>';
						if(stations[i].cheap > 0) {
							text += '<span class="bg1">降</span> &yen;&nbsp;<span class="bg2">' + stations[i].price + '</span>'
						} else {
							text += '<span></span> &yen;&nbsp;<span class="bg2">' + stations[i].price + '</span>'
						}
						text += '</div>';
						text += '</div>';
						text += '</div>';
						if(stations[i].cooperation == true) {
							text += '<div class="item-text"><span class="tip1" style="margin-right:80%">扫码付</span></div>'
						} else {
							text += '<div class="item-text"><span class="tip1" style="margin-right:80%;background:#f90;">可报销</span></div>'
						}
						text += '</div>';
						text += '</div>';
						text += '<div class="item-inner bot">';
						text += '<div class="item-title-row p_l__75">';
						text += '<div class="item-title">' + stations[i].address + '</div>';
						if(stations[i].distance > 1 || stations[i].distance == 1) {
							text += '<div class="item-after"><i class="fa fa-map-marker fa-lg lineHnor coblue"></i>&nbsp;' + stations[i].distance + '公里</div>'
						} else {
							text += '<div class="item-after"><i class="fa fa-map-marker fa-lg lineHnor coblue"></i>&nbsp;' + (stations[i].distance * 1000.0).toFixed(2) + 'm</div>'
						}
						text += '</div>';
						text += '</div>';
						text += '</a>';
						text += '</li>'
					}
					$('.list-block.media-list ul').html(text);

					sessionStorage.setItem('text', text)
					$('#list-block ul li').on("click", function() {
						var id = $(this).attr('id');
						var coordinatex = $(this).attr('coordinatex');
						var coordinatey = $(this).attr('coordinatey');
						var stationtype = $(this).attr('stationtype');
						window.location.href = 'gas_station_details.html?id=' + id + '&coordinatex=' + coordinatex + '&coordinatey=' + coordinatey + '&stationtype=' + stationtype
					})
				} else {
					text = '<div style="margin-top: 25%;">对不起，周围没有可用的加油站!</div>';
					$('.list-block.media-list ul').html(text)
				}
			}
		})
	}

	$(document).on("pageInit", "#Y_pwdset_index", function(e, id, page) {});
	$(document).on("click", "#enable_pwd", function() {
		var _thisCBox = $(this).children('input'),
			toggle = _thisCBox.prop("checked");
		_thisCBox.prop("disabled", true);
		if(toggle) {
			_thisCBox.prop("checked", false)
		} else {
			_thisCBox.prop("checked", true);
			$.router.load("#Y_pwdset_enabled")
		}
	});
	$("#safePWD1").blur(function() {
		var _this = $(this),
			pd = _this.val(),
			_parent = _this.parents("li").first();
		if(reg_six.test(pd)) {
			_parent.find(".error").remove()
		} else {
			if(_parent.find(".error").length <= 0) {
				$("<div />", {
					text: "安全密码设置有误",
					class: "p_x__75 color-danger error"
				}).appendTo(_parent)
			}
		}
	});
	$("#safePWD1_2").blur(function() {
		var _this = $(this),
			pd1 = $("#safePWD1").val(),
			pd2 = _this.val(),
			_parent = _this.parents("li").first();
		if(pd1 == pd2) {
			_parent.find(".error").remove()
		} else {
			if(_parent.find(".error").length <= 0) {
				$("<div />", {
					text: "两次密码输入不一致",
					class: "p_x__75 color-danger error"
				}).appendTo(_parent)
			}
		}
	});
	$("#safePWD_btn_submit").click(function() {
		var spwd1 = $("#safePWD1"),
			spwd2 = $("#safePWD1_2"),
			_parent2 = spwd2.parents("li").first();
		if(spwd1.val() != spwd2.val()) {
			if(_parent2.find(".error").length <= 0) {
				$("<div />", {
					text: "两次密码输入不一致",
					class: "p_x__75 color-danger error"
				}).appendTo(_parent2)
			}
			return false
		}
	});
	$(document).on("pageInit", "#Y_gasSiteList", function(e, id, page) {
		$(page).on('click', '.gasDrop .selected', function() {
			$(this).siblings(".dropdown1").toggleClass("hide")
		});
		$(page).on('click', '.gasDrop .dropdown1 li', function() {
			var _this = $(this),
				_txt = _this.text(),
				_id = _this.attr('id')

			_this.parent().addClass("hide").siblings(".selected").text(_txt)
			if(_id == 1) {
				gasno(93)
			} else if(_id == 2) {
				gasno(97)
			} else if(_id == 3) {
				gasno(0)
			}

		})
	});
	$.init()
});

function gasno1(str, gasnoid) {

	var str = str;
	getLocation()

	function getLocation() {
		if(navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(showPosition);
		} else {
			x.innerHTML = "Geolocation is not supported by this browser.";
		}
	}

	function showPosition(position) {
		var y = position.coords.latitude;
		var x = position.coords.longitude;
		var val = localStorage.getItem("phone");
		var x = sessionStorage.getItem('x')
		var y = sessionStorage.getItem('y')

		var param = '{"username":' + val + ',"login":' + true + ',"gasno":' + str + ',"coordinatey":' + y + ',"coordinatex":' + x + ',"gasnoid":"' + gasnoid + '"}';
		param = getAES(param);
		var data = {
			'param': param,
			'version': "2.0.5"
		};
		var dataStr = JSON.stringify(data);
		$.ajax({
			url: strUrl + "ybb/post?url=getStationMessageStationAction",
			contentType: "application/json",
			data: data,
			async: true,
			success: function(data) {
				data = getDAes(data);
				var jsonData = JSON.parse(data);
				console.log(jsonData)
				var gasnolist = jsonData.gasnolist;
				var stations = jsonData.stations;
				var html = "";
				var text = "";
				console.log(stations)
				if(stations != undefined) {
					console.log('go')
					var arr = [];
					$.each(stations, function(i, v) {
						var obj = {};
						obj['coordinatex'] = v.coordinatex;
						obj['coordinatey'] = v.coordinatey;
						obj['id'] = v.id;
						arr[i] = obj
					});
					sessionStorage.setItem('listArr',JSON.stringify(arr))
					for(var i = 0; i < stations.length; i += 1) {
						text += '<li  id = ' + stations[i].stationid + ' coordinatex = ' + stations[i].coordinatex + ' coordinatey = ' + stations[i].coordinatey + ' stationtype = ' + stations[i].stationtype + '>';
						text += '<a href="#"  class=""external">';
						text += '<div class="item-content">';
						if(stations[i].stationtype == 1) {
							text += '<div class="item-media"><img src="img/zsy.png"></div>'
						} else if(stations[i].stationtype == 2) {
							text += '<div class="item-media"><img src="img/zsh.png"></div>'
						} else {
							text += '<div class="item-media"><img src="img/yz.png"></div>'
						}
						text += '<div class="item-inner">';
						text += '<div class="item-title-row">';
						text += '<div class="item-title">' + stations[i].name + '</div>';
						text += '<div class="item-after price">';
						text += '<div>';
						if(stations[i].cheap > 0) {
							text += '<span class="bg1">降</span> &yen;&nbsp;<span class="bg2">' + stations[i].price + '</span>'
						} else {
							text += '<span></span> &yen;&nbsp;<span class="bg2">' + stations[i].price + '</span>'
						}
						text += '</div>';
						text += '</div>';
						text += '</div>';
						if(stations[i].cooperation == true) {
							text += '<div class="item-text"><span class="tip1" style="margin-right:80%">扫码付</span></div>'
						} else {
							text += '<div class="item-text"><span class="tip1" style="margin-right:80%;background:#f90;">可报销</span></div>'
						}
						text += '</div>';
						text += '</div>';
						text += '<div class="item-inner bot">';
						text += '<div class="item-title-row p_l__75">';
						text += '<div class="item-title">' + stations[i].address + '</div>';
						if(stations[i].distance > 1 || stations[i].distance == 1) {
							text += '<div class="item-after"><i class="fa fa-map-marker fa-lg lineHnor coblue"></i>&nbsp;' + stations[i].distance + '公里</div>'
						} else {
							text += '<div class="item-after"><i class="fa fa-map-marker fa-lg lineHnor coblue"></i>&nbsp;' + (stations[i].distance * 1000.0).toFixed(2) + 'm</div>'
						}
						text += '</div>';
						text += '</div>';
						text += '</a>';
						text += '</li>'
					}

					$('.list-block.media-list ul').html(text);

					sessionStorage.setItem('text', text)
					$('#list-block ul li').on("click", function() {
						var id = $(this).attr('id');
						var coordinatex = $(this).attr('coordinatex');
						var coordinatey = $(this).attr('coordinatey');
						var stationtype = $(this).attr('stationtype');
						window.location.href = 'gas_station_details.html?id=' + id + '&coordinatex=' + coordinatex + '&coordinatey=' + coordinatey+ '&stationtype=' + stationtype
					})
				} else {
					text = '<div style="margin-top: 25%;">对不起，周围没有可用的加油站!</div>';
					$('.list-block.media-list ul').html(text)
				}
			}
		})
	}
}
